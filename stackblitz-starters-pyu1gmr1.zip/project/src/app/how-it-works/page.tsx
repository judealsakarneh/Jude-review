export default function HowItWorksPage() {
  return (
    <div className="max-w-5xl mx-auto px-6 py-16">
      <h1 className="text-3xl font-bold text-brand mb-4">How It Works</h1>
      <p className="text-slate-400">Step-by-step guide coming soon.</p>
    </div>
  );
}
