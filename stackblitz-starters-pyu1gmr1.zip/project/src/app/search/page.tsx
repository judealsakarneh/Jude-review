export default function SearchPage() {
  return (
    <div className="max-w-5xl mx-auto px-6 py-16">
      <h1 className="text-3xl font-bold text-brand mb-4">Search Freelancers</h1>
      <p className="text-slate-400">Search functionality will be added soon.</p>
    </div>
  );
}
