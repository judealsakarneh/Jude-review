import Link from "next/link";

export default function HomePage() {
  return (
    <div className="relative">
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-slate-800/70 bg-gradient-to-b from-slate-950/90 to-slate-950/60">
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute -left-40 top-16 h-80 w-80 rounded-full bg-brand/10 blur-3xl" />
          <div className="absolute right-0 top-40 h-64 w-64 rounded-full bg-cyan-500/10 blur-3xl" />
        </div>

        <div className="relative mx-auto flex max-w-7xl flex-col gap-10 px-4 py-14 sm:px-6 lg:flex-row lg:items-center lg:py-20 lg:px-8">
          <div className="max-w-xl space-y-6 lg:max-w-2xl">
            <p className="inline-flex rounded-full border border-brand/40 bg-slate-900/70 px-3 py-1 text-xs font-medium text-brand shadow-[0_0_18px_rgba(53,191,255,0.55)]">
              Humans + AI • Freelancers who build the future
            </p>
            <h1 className="font-heading text-3xl tracking-tight text-slate-50 sm:text-4xl lg:text-5xl">
              Build faster with{" "}
              <span className="text-brand">
                AI freelancers
              </span>{" "}
              who ship real outcomes.
            </h1>
            <p className="max-w-xl text-sm text-slate-300 sm:text-base">
              Humanaira connects you with vetted AI freelancers across agents,
              automations, analytics, and AI content. They bring the models,
              you bring the vision — together you launch what used to take
              months in days.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link
                href="/search"
                className="ai-cta inline-flex items-center justify-center rounded-full bg-brand px-6 py-2 text-sm font-medium text-slate-950 shadow-lg hover:bg-sky-300 transition-colors"
              >
                Browse AI services
              </Link>
              <Link
                href="/auth/sign-up?role=freelancer"
                className="inline-flex items-center justify-center rounded-full border border-slate-600 bg-slate-950/80 px-6 py-2 text-sm font-medium text-slate-100 hover:border-brand hover:text-brand transition-colors"
              >
                Offer your AI skills
              </Link>
            </div>
            <div className="flex flex-wrap gap-3 text-xs text-slate-400">
              <span className="rounded-full border border-slate-700 bg-slate-950/70 px-3 py-1">
                ✨ Agents & automations
              </span>
              <span className="rounded-full border border-slate-700 bg-slate-950/70 px-3 py-1">
                📊 Data & analytics
              </span>
              <span className="rounded-full border border-slate-700 bg-slate-950/70 px-3 py-1">
                🧠 LLM apps & chatbots
              </span>
            </div>
          </div>

          {/* Right side visual */}
          <div className="relative mt-8 w-full max-w-md lg:mt-0 lg:max-w-lg">
            <div className="glass-card hover-lift relative overflow-hidden p-5">
              <div className="mb-4 flex items-center justify-between text-xs text-slate-300/80">
                <span>AI project impact preview</span>
                <span className="rounded-full border border-emerald-400/40 bg-emerald-500/5 px-2 py-0.5 text-[11px] text-emerald-300">
                  Live examples
                </span>
              </div>
              <div className="space-y-4 text-xs text-slate-200/90">
                <ComparisonRow
                  label="Without AI freelancers"
                  items={[
                    "Manual, repetitive work",
                    "Slow iterations",
                    "Fragmented tooling",
                    "Hard to scale experiments"
                  ]}
                />
                <ComparisonRow
                  label="With Humanaira AI freelancers"
                  highlight
                  items={[
                    "Automated flows built for you",
                    "Faster launches & experiments",
                    "Better data visibility",
                    "Humans + AI in one workflow"
                  ]}
                />
              </div>
              <div className="mt-5 flex items-center justify-between rounded-xl border border-slate-700/70 bg-slate-950/90 px-4 py-3 text-xs text-slate-300">
                <div className="space-y-0.5">
                  <p className="font-medium text-slate-100">
                    Ready to see what AI can do in your work?
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Browse real services or post what you need — humans + AI
                    handle the rest.
                  </p>
                </div>
                <Link
                  href="/search"
                  className="rounded-full bg-brand/90 px-3 py-1.5 text-[11px] font-semibold text-slate-950 hover:bg-sky-300 transition-colors"
                >
                  Start now
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Later we’ll add: categories, featured freelancers, blog, “how it works” etc. */}
    </div>
  );
}

function ComparisonRow(props: {
  label: string;
  items: string[];
  highlight?: boolean;
}) {
  const { label, items, highlight } = props;
  return (
    <div
      className={`rounded-2xl border px-4 py-3 ${
        highlight
          ? "border-brand/60 bg-slate-900/85 shadow-[0_0_30px_rgba(53,191,255,0.35)]"
          : "border-slate-700/80 bg-slate-950/80"
      }`}
    >
      <p
        className={`mb-1 text-[11px] font-semibold ${
          highlight ? "text-brand" : "text-slate-400"
        }`}
      >
        {label}
      </p>
      <ul className="grid gap-1 text-[11px] text-slate-200/85 sm:grid-cols-2">
        {items.map((item) => (
          <li key={item} className="flex items-start gap-1.5">
            <span className="mt-0.5 h-1.5 w-1.5 rounded-full bg-brand/70" />
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}