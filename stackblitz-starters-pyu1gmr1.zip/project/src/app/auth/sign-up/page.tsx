"use client";

import { FormEvent, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { createSupabaseBrowserClient } from "@/lib/supabase-browser";

type Role = "buyer" | "freelancer";

export default function SignUpPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialRole = (searchParams.get("role") as Role) || "buyer";

  const [role, setRole] = useState<Role>(initialRole);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const supabase = useMemo(() => createSupabaseBrowserClient(), []);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setErrorMsg(null);

    const {
      data: { user },
      error
    } = await supabase.auth.signUp({
      email,
      password
    });

    if (error || !user) {
      setErrorMsg(error?.message || "Could not create account.");
      setLoading(false);
      return;
    }

    // Create / update profile row linked to auth user
    const { error: profileError } = await supabase.from("profiles").upsert({
      id: user.id,
      role,
      name
    });

    if (profileError) {
      console.error(profileError);
      // not fatal, but we show something
      setErrorMsg("Account created but profile setup failed. Please contact support.");
      setLoading(false);
      return;
    }

    // Optionally redirect based on role
    if (role === "freelancer") {
      router.push("/"); // later: /dashboard/freelancer
    } else {
      router.push("/"); // later: /dashboard/buyer
    }
    router.refresh();
  }

  return (
    <div className="flex min-h-[calc(100vh-80px)] items-center justify-center px-4 py-10">
      <div className="glass-card w-full max-w-md p-6">
        <h1 className="mb-2 font-heading text-2xl text-slate-50">
          Create your account
        </h1>
        <p className="mb-6 text-sm text-slate-400">
          Join Humanaira as a buyer or an AI freelancer.
        </p>

        <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-slate-700/80 bg-slate-950/80 p-1 text-xs">
          <button
            type="button"
            onClick={() => setRole("buyer")}
            className={`flex-1 rounded-full px-3 py-1.5 text-center transition-colors ${
              role === "buyer"
                ? "bg-brand text-slate-950 font-semibold"
                : "text-slate-300"
            }`}
          >
            I&apos;m a buyer
          </button>
          <button
            type="button"
            onClick={() => setRole("freelancer")}
            className={`flex-1 rounded-full px-3 py-1.5 text-center transition-colors ${
              role === "freelancer"
                ? "bg-brand text-slate-950 font-semibold"
                : "text-slate-300"
            }`}
          >
            I&apos;m a freelancer
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300">
              Full name
            </label>
            <input
              type="text"
              required
              className="w-full rounded-xl border border-slate-700 bg-slate-950/60 px-3 py-2 text-sm text-slate-100 outline-none focus:border-brand focus:ring-1 focus:ring-brand/70"
              placeholder="Alex Doe"
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoComplete="name"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300">Email</label>
            <input
              type="email"
              required
              className="w-full rounded-xl border border-slate-700 bg-slate-950/60 px-3 py-2 text-sm text-slate-100 outline-none focus:border-brand focus:ring-1 focus:ring-brand/70"
              placeholder="you@company.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300">
              Password
            </label>
            <input
              type="password"
              required
              minLength={6}
              className="w-full rounded-xl border border-slate-700 bg-slate-950/60 px-3 py-2 text-sm text-slate-100 outline-none focus:border-brand focus:ring-1 focus:ring-brand/70"
              placeholder="At least 6 characters"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="new-password"
            />
          </div>

          {errorMsg && (
            <p className="text-xs text-red-400 bg-red-950/40 border border-red-500/40 rounded-lg px-3 py-2">
              {errorMsg}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="ai-cta flex w-full items-center justify-center rounded-full bg-brand px-4 py-2 text-sm font-semibold text-slate-950 shadow-lg hover:bg-sky-300 transition-colors disabled:opacity-60"
          >
            {loading
              ? "Creating account..."
              : role === "freelancer"
              ? "Join as freelancer"
              : "Sign up as buyer"}
          </button>
        </form>

        <p className="mt-4 text-xs text-slate-400">
          Already have an account?{" "}
          <a href="/auth/sign-in" className="text-brand hover:underline">
            Sign in
          </a>
        </p>
      </div>
    </div>
  );
}
