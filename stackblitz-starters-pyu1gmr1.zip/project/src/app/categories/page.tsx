export default function CategoriesPage() {
  return (
    <div className="max-w-5xl mx-auto px-6 py-16">
      <h1 className="text-3xl font-bold text-brand mb-4">Categories</h1>
      <p className="text-slate-400">Browse AI freelancer categories.</p>
    </div>
  );
}
