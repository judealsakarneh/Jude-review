import type { Metadata } from "next";
import "./globals.css";
import { Inter, Space_Grotesk } from "next/font/google";
import Link from "next/link";
import { ReactNode } from "react";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap"
});

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-heading",
  display: "swap"
});

export const metadata: Metadata = {
  title: "Humanaira – AI Freelancers Marketplace",
  description:
    "Humanaira connects you with world-class AI freelancers to build automations, agents, analytics, AI content, and more. Humans + AI, together."
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable} ${spaceGrotesk.variable}`}>
      <body className="ai-bg ai-bg-gradient min-h-screen text-slate-100">
        <div className="flex min-h-screen flex-col">
          <SiteHeader />
          <main className="flex-1">{children}</main>
          <SiteFooter />
        </div>
      </body>
    </html>
  );
}

function Logo() {
  return (
    <div className="logo-frame">
      <div className="logo-frame-inner px-4 py-1.5 flex items-center gap-2">
        <span className="inline-flex h-2 w-2 rounded-full bg-brand shadow-[0_0_12px_rgba(53,191,255,0.9)]" />
        <span className="font-heading text-lg tracking-tight">
          <span className="text-brand font-semibold">hum</span>
          <span className="text-brand font-semibold">an</span>
          <span className="text-white font-semibold">ai</span>
          <span className="text-brand font-semibold">ra</span>
        </span>
      </div>
    </div>
  );
}

function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 glass-header">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <div className="flex items-center gap-6">
          <Link href="/">
            <Logo />
          </Link>
          <nav className="hidden items-center gap-4 text-sm text-slate-200/80 md:flex">
            <NavLink href="/search">Browse Freelancers</NavLink>
            <NavLink href="/categories">Categories</NavLink>
            <NavLink href="/blog">Blog</NavLink>
            <NavLink href="/how-it-works">How It Works</NavLink>
          </nav>
        </div>
        <div className="flex items-center gap-3">
          <Link
            href="/auth/sign-in"
            className="hidden rounded-full border border-slate-500/70 px-4 py-1.5 text-sm text-slate-200 hover:border-brand hover:text-brand transition-colors md:inline-flex"
          >
            Sign in
          </Link>
          <Link
            href="/auth/sign-up?role=buyer"
            className="hidden ai-cta rounded-full bg-brand px-4 py-1.5 text-sm font-medium text-slate-950 shadow-lg hover:bg-sky-300 transition-colors md:inline-flex"
          >
            Browse services
          </Link>
          <Link
            href="/auth/sign-up?role=freelancer"
            className="rounded-full border border-brand/70 bg-slate-900/70 px-4 py-1.5 text-sm font-medium text-brand shadow-[0_0_22px_rgba(53,191,255,0.5)] hover:bg-slate-900 transition-colors"
          >
            Join as freelancer
          </Link>
        </div>
      </div>
    </header>
  );
}

function NavLink({ href, children }: { href: string; children: ReactNode }) {
  return (
    <Link
      href={href}
      className="rounded-full px-3 py-1 text-xs font-medium text-slate-300/80 hover:text-brand hover:bg-slate-900/60 transition-colors"
    >
      {children}
    </Link>
  );
}

function SiteFooter() {
  return (
    <footer className="border-t border-slate-800/80 bg-slate-950/80">
      <div className="mx-auto flex max-w-7xl flex-col gap-8 px-4 py-8 sm:px-6 lg:px-8 lg:flex-row lg:items-start lg:justify-between">
        <div className="space-y-3 max-w-md">
          <Logo />
          <p className="text-sm text-slate-400">
            Humanaira is where humans and AI freelancers collaborate to ship
            better work, faster. From agents to automations, we&apos;re building
            the future of AI-powered freelancing.
          </p>
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400/80">
            <span className="rounded-full border border-emerald-500/40 bg-emerald-500/5 px-3 py-1">
              🔒 Secured by Stripe payments
            </span>
            <span className="rounded-full border border-slate-600/60 bg-slate-900/80 px-3 py-1">
              Humans + AI, together.
            </span>
          </div>
        </div>
        <div className="grid flex-1 grid-cols-2 gap-6 text-sm text-slate-300 sm:grid-cols-3 lg:grid-cols-4">
          <div className="space-y-2">
            <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-400">
              Platform
            </h4>
            <FooterLink href="/search">Browse freelancers</FooterLink>
            <FooterLink href="/categories">Categories</FooterLink>
            <FooterLink href="/blog">Blog</FooterLink>
            <FooterLink href="/how-it-works">How it works</FooterLink>
          </div>
          <div className="space-y-2">
            <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-400">
              Company
            </h4>
            <FooterLink href="/about">About</FooterLink>
            <FooterLink href="/support">Customer support</FooterLink>
            <FooterLink href="/contact">Contact</FooterLink>
            <span className="block text-xs text-slate-400">
              hello@humanaira.com
            </span>
          </div>
          <div className="space-y-2">
            <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-400">
              Legal
            </h4>
            <FooterLink href="/terms">Terms</FooterLink>
            <FooterLink href="/privacy">Privacy</FooterLink>
            <FooterLink href="/security">Security</FooterLink>
            <FooterLink href="/refund">Refund policy</FooterLink>
          </div>
          <div className="space-y-2">
            <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-400">
              Social
            </h4>
            <a
              href="https://www.linkedin.com/company/humanaira/"
              target="_blank"
              rel="noreferrer"
              className="block text-xs text-slate-300/90 hover:text-brand transition-colors"
            >
              LinkedIn
            </a>
            <a
              href="https://www.instagram.com/humanairaglobal"
              target="_blank"
              rel="noreferrer"
              className="block text-xs text-slate-300/90 hover:text-brand transition-colors"
            >
              Instagram
            </a>
          </div>
        </div>
      </div>
      <div className="border-t border-slate-800/80 bg-slate-950/95">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 text-xs text-slate-500 sm:px-6 lg:px-8">
          <span>© {new Date().getFullYear()} Humanaira. All rights reserved.</span>
          <span className="text-slate-500/80">
            Built for AI + human collaboration.
          </span>
        </div>
      </div>
    </footer>
  );
}

function FooterLink({ href, children }: { href: string; children: ReactNode }) {
  return (
    <Link
      href={href}
      className="block text-xs text-slate-300/90 hover:text-brand transition-colors"
    >
      {children}
    </Link>
  );
}