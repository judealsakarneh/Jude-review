import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./src/app/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        brand: "#35BFFF"
      },
      backgroundImage: {
        "ai-grid": "radial-gradient(circle at 1px 1px, rgba(53,191,255,0.2) 1px, transparent 0)"
      }
    }
  },
  plugins: []
};

export default config;